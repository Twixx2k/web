<?php
  include 'adminheader.php';
  $conn = mysqli_connect('localhost','root','','index_db') or die('connection failed')
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
  
</style>
<body style="">
  <div class="container mt-5">

<section class="browserPage" id="homeFront">       

<table class="table mt-5" id="table">
  <thead>
    <tr>
    <h1 class="heading mt-5">APPOINTMENT LIST</h1>
      <th scope="col" class="adminFontColor">Appointment id</th>
      <th scope="col" class="adminFontColor">PatientName</th>
      <th scope="col" class="adminFontColor">PhoneNumber</th>
      <th scope="col" class="adminFontColor">Services</th>
      <th scope="col" class="adminFontColor">Date/Time</th>
      <th scope="col" class="adminFontColor">Status</th>
      <th scope="col" class="adminFontColor">Action</th>
     
    </tr>
  </thead>
  <tbody>

  <?php 
  
  $sql1="Select * from appointment ";
  
  
 

  $result=mysqli_query($conn,$sql1);
 

  if ($result) {
     while ( $row=mysqli_fetch_assoc($result)){

        $booking_ID=$row ['id'];
        $customerName= $row['patientName'];
        $services= $row['services'];
        $dateTime=$row ['dateTime'];
        $status=$row ['status'];
        $phone=$row ['phone'];
         
         
         echo ' <tr>
         <th scope="row" class="adminFontColor">'.$booking_ID.'</th>
         <td class="adminFontColor">'.$customerName.'</td>
         <td class="adminFontColor">'.$phone.'</td>
         <td class="adminFontColor">'.$services.'</td>
         <td class="adminFontColor">'.$dateTime.'</td>
         <td class="adminFontColor">'.$status.'</td>
        
        
       
         <td>
         <div>
         <form action="updateDeleteStatus.php">
<button class="btn btn-primary"><a href="updateDeleteStatus.php? update= '.$booking_ID.'" class ="text-light">Update</a></button>
<button class="btn btn-danger"><a href="updateDeleteStatus.php? delete= '.$booking_ID.'" class ="text-light">Delete</a></button>
<h1> </h1>
</div>
</form>



</td>
         </tr>';
     }
  }
  
  ?>

    <script src= "displayJS.js"></script>

    </div>

   
  </tbody>
</table>
    
</body>
</html>