<?php

$server = "sql105.epizy.com";
$username = "epiz_32905715";
$password = "GwQv17jqu52Ivus";
$dbname = "epiz_32905715_radiantdentistry";

$conn = mysqli_connect('localhost','root','','index_db');

?>